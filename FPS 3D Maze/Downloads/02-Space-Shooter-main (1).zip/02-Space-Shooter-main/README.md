# 02-Space-Shooter
Space shooting 2d game for project 2

Finished the Project 2 Space Shooter in which i create a level from a top town space shooter shooting enemies and dodging attacks.
February 24, 2021

The level is really cool. You control a red spaceship and you can fly left and right. You can shoot two different types of weapons and you have to dodge the mines and bullets from enemy ships. There is a space background and a score in the corner.

I used different assets from online to help me create the sprites as well as the demonstration video helping me write the code and figure out how to implement the features into the short level.

Again i referenced different online websites to find sprites and used the demonstration video.

I will use this knowledge to help me in future projects especially in writing the lines and figuring out what all the nodes do.

Created By Jalen Slutzky
